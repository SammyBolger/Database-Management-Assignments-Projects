-- make the database and use it
CREATE DATABASE ShippingDB;
USE ShippingDB;

-- 1. sea/ocean/lake table
CREATE TABLE SEA_OCEAN_LAKE (
    Name VARCHAR(100) PRIMARY KEY
);

-- 2. state/country table
CREATE TABLE STATE_COUNTRY (
    Name VARCHAR(100) PRIMARY KEY,
    Continent VARCHAR(100)
);

-- 3. port table (links to state/country and sea/ocean/lake)
CREATE TABLE PORT (
    Pname VARCHAR(100) PRIMARY KEY,
    Country_Name VARCHAR(100),
    Water_Body_Name VARCHAR(100),
    FOREIGN KEY (Country_Name) REFERENCES STATE_COUNTRY(Name),
    FOREIGN KEY (Water_Body_Name) REFERENCES SEA_OCEAN_LAKE(Name)
);

-- 4. ship type table
CREATE TABLE SHIP_TYPE (
    Type VARCHAR(50) PRIMARY KEY,
    Tonnage INT,
    Hull VARCHAR(50)
);

-- 5. ship table (has a type and home port)
CREATE TABLE SHIP (
    Sname VARCHAR(100) PRIMARY KEY,
    Owner VARCHAR(100),
    Type VARCHAR(50),
    Home_Port VARCHAR(100),
    FOREIGN KEY (Type) REFERENCES SHIP_TYPE(Type),
    FOREIGN KEY (Home_Port) REFERENCES PORT(Pname)
);

-- 6. ship movement table (like the history of where it's been)
CREATE TABLE SHIP_MOVEMENT (
    Sname VARCHAR(100),
    Time_stamp DATETIME,
    Latitude DECIMAL(9,6),
    Longitude DECIMAL(9,6),
    PRIMARY KEY (Sname, Time_stamp),
    FOREIGN KEY (Sname) REFERENCES SHIP(Sname)
);

-- 7. port visit table (logs when a ship is at a port)
CREATE TABLE PORT_VISIT (
    Sname VARCHAR(100),
    Pname VARCHAR(100),
    Start_date DATE,
    End_date DATE,
    PRIMARY KEY (Sname, Pname, Start_date),
    FOREIGN KEY (Sname) REFERENCES SHIP(Sname),
    FOREIGN KEY (Pname) REFERENCES PORT(Pname)
);
