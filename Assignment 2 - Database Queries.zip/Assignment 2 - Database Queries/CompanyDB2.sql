-- a. Retrieve the names of all employees in department 5 who work more than 10 hours per week on the ProductX project.
SELECT E.FName, E.LName
FROM Employee E
JOIN WorksOn W ON E.SSN = W.ESSN
JOIN Project P ON W.PNo = P.PNumber
WHERE E.DNo = 5 AND P.PName = 'ProductX' AND W.Hours > 10;

-- b. List the names of all employees who have a dependent with the same first name as themselves.
SELECT E.FName, E.LName
FROM Employee E
JOIN Dependent D ON E.SSN = D.ESSN
WHERE E.FName = D.DependentName;
SELECT * FROM Employee;
SELECT * FROM Dependent;
-- I think it did not return any results because there are no employees in the current dataset who have a dependent with the same first name as themselves

-- c. Find the names of all employees who are directly supervised by 'Franklin Wong'.
SELECT E.FName, E.LName
FROM Employee E
JOIN Employee S ON E.SuperSSN = S.SSN
WHERE S.FName = 'Franklin' AND S.LName = 'Wong';
