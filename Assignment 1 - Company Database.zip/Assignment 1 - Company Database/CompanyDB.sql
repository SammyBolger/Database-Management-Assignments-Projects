CREATE DATABASE CompanyDB;
USE CompanyDB;

CREATE TABLE Department (
    DNumber INT PRIMARY KEY,
    DName VARCHAR(50) UNIQUE,
    MgrSSN CHAR(9),
    MgrStartDate DATE
);

INSERT INTO Department (DName, DNumber, MgrSSN, MgrStartDate) VALUES
('Research', 5, '333445555', '1988-05-22'),
('Administration', 4, '987654321', '1995-01-01'),
('Headquarters', 1, '888665555', '1981-06-19');

CREATE TABLE DeptLocations (
    DNumber INT,
    DLocation VARCHAR(50),
    PRIMARY KEY (DNumber, DLocation),
    FOREIGN KEY (DNumber) REFERENCES Department(DNumber)
);

INSERT INTO DeptLocations (Dnumber, Dlocation) VALUES
('1', 'Houtston'),
('4', 'Stafford'),
('5', 'Bellaire'),
('5', 'Sugarland'),
('5', 'Houtston');

CREATE TABLE Employee (
    SSN CHAR(9) PRIMARY KEY,
    FName VARCHAR(50),
    LName VARCHAR(50),
    BDate DATE,
    Address VARCHAR(255),
    Salary DECIMAL(10,2),
    SuperSSN CHAR(9),
    DNo INT,
    FOREIGN KEY (SuperSSN) REFERENCES Employee(SSN),
    FOREIGN KEY (DNo) REFERENCES Department(DNumber)
);

ALTER TABLE Employee ADD COLUMN MInit CHAR(1);
ALTER TABLE Employee ADD COLUMN Sex CHAR(1);

INSERT INTO Employee (FName, MInit, LName, SSN, BDate, Address, Sex, Salary, SuperSSN, DNo) VALUES
('James', 'E', 'Borg', '888665555', '1937-11-10', '450 Stone Houston, TX', 'M', 55000, NULL, 1);

INSERT INTO Employee (FName, MInit, LName, SSN, BDate, Address, Sex, Salary, SuperSSN, DNo) VALUES
('Franklin', 'T', 'Wong', '333445555', '1955-12-08', '638 Voss, Houston, TX', 'M', 40000, '888665555', 5);

INSERT INTO Employee (FName, MInit, LName, SSN, BDate, Address, Sex, Salary, SuperSSN, DNo) VALUES
('John', 'B', 'Smith', '123456789', '1965-01-09', '731 Fondren, Houston, TX', 'M', 30000, '333445555', 5),
('Ramesh', 'K', 'Narayan', '666884444', '1962-09-15', '975 Fire Oak, Humble, TX', 'M', 38000, '333445555', 5),
('Joyce', 'A', 'English', '453453453', '1972-07-31', '5631 Rice, Houston, TX', 'F', 25000, '333445555', 5);

INSERT INTO Employee (FName, MInit, LName, SSN, BDate, Address, Sex, Salary, SuperSSN, DNo) VALUES
('Jennifer', 'S', 'Wallace', '987654321', '1941-06-20', '291 Berry, Bellaire, TX', 'F', 43000, '888665555', 4);

INSERT INTO Employee (FName, MInit, LName, SSN, BDate, Address, Sex, Salary, SuperSSN, DNo) VALUES
('Alicia', 'J', 'Zelaya', '999887777', '1968-01-19', '3321 Castle, Spring, TX', 'F', 25000, '987654321', 4),
('Ahmad', 'V', 'Jabbar', '987987987', '1969-03-29', '980 Dallas, Houston, TX', 'M', 25000, '987654321', 4);

CREATE TABLE Project (
    PNumber INT PRIMARY KEY,
    PName VARCHAR(50),
    PLocation VARCHAR(50),
    DNo INT,
    FOREIGN KEY (DNo) REFERENCES Department(DNumber)
);

INSERT INTO Project (Pname, Pnumber, Plocation, Dno) VALUES
('ProductX', '1', 'Bellaire', 5),
('ProductY', '2', 'Sugarland', 5),
('ProductZ', '3', 'Houston', 5),
('Computerization', '10', 'Stafford', 4),
('Reorganization', '20', 'Houston', 1),
('Newbenefits', '30', 'Stafford', 4);

CREATE TABLE WorksOn (
    ESSN CHAR(9),
    PNo INT,
    Hours DECIMAL(5,2),
    PRIMARY KEY (ESSN, PNo),
    FOREIGN KEY (ESSN) REFERENCES Employee(SSN),
    FOREIGN KEY (PNo) REFERENCES Project(PNumber)
);

INSERT INTO WorksOn (Essn, Pno, Hours) VALUES
('123456789', '1', '32.5'),
('123456789', '2', '7.5'),
('666884444', '3', '40.0'),
('453453453', '1', '20.0'),
('453453453', '2', '20.0'),
('333445555', '2', '10.0'),
('333445555', '3', '10.0'),
('333445555', '10', '10.0'),
('333445555', '20', '10.0'),
('999887777', '30', '30.0'),
('999887777', '10', '10.0'),
('987987987', '10', '35.0'),
('987987987', '30', '5.0'),
('987654321', '30', '20.0'),
('987654321', '20', '15.0'),
('888665555', '20', NULL);

CREATE TABLE Dependent (
    ESSN CHAR(9),
    DependentName VARCHAR(50),
    Sex CHAR(1),
    BDate DATE,
    Relationship VARCHAR(50),
    PRIMARY KEY (ESSN, DependentName),
    FOREIGN KEY (ESSN) REFERENCES Employee(SSN)
);

INSERT INTO Dependent (Essn, DependentName, Sex, BDate, Relationship) VALUES
('333445555', 'Alice', 'F', '1986-04-05', 'Daughter'),
('333445555', 'Theodore', 'M', '1983-10-25', 'Son'),
('333445555', 'Joy', 'F', '1958-05-03', 'Spouse'),
('987654321', 'Abner', 'M', '1942-02-28', 'Spouse'),
('123456789', 'Micheal', 'M', '1988-01-04', 'Son'),
('123456789', 'Alice', 'F', '1988-12-30', 'Daughter'),
('123456789', 'Elizabeth', 'F', '1967-05-05', 'Spouse');

SELECT * FROM Department;
SELECT * FROM DeptLocations;
SELECT * FROM Employee;
SELECT * FROM Project;
SELECT * FROM WorksOn;
SELECT * FROM Dependent;


ALTER TABLE Employee MODIFY SuperSSN CHAR(9) DEFAULT NULL;
ALTER TABLE Project MODIFY DNo INT NOT NULL;
ALTER TABLE Department MODIFY MgrSSN CHAR(9) DEFAULT NULL;
ALTER TABLE WorksOn MODIFY PNo INT NOT NULL;
ALTER TABLE Dependent MODIFY DependentName VARCHAR(50) NOT NULL;

-- a. Insert <'Robert', 'F, 'Scott, 943775543', '1972-06-21', '2365 Newcastle Rd, Bellaire, TX', M, 58000, 888665555', 1> into EMPLOYEE.
INSERT INTO Employee (FName, MInit, LName, SSN, BDate, Address, Sex, Salary, SuperSSN, DNo)
VALUES ('Robert', 'F', 'Scott', '943775543', '1972-06-21', '2365 Newcastle Rd, Bellaire, TX', 'M', 58000, '888665555', 1);

-- b. Insert <'ProductA', 4, 'Bellaire', 2> into PROJECT.
INSERT INTO Project (PName, PNumber, PLocation, DNo)
VALUES ('ProductA', 4, 'Bellaire', 2);

-- c. Insert <'Production', 4, '943775543', '2007-10-01'> into DEPARTMENT.
UPDATE Department
SET DName = 'Production', MgrSSN = '943775543', MgrStartDate = '2007-10-01'
WHERE DNumber = 4;
UPDATE Department 
SET MgrSSN = '943775543', MgrStartDate = '2007-10-01'
WHERE DNumber = 4;

﻿﻿﻿-- d. Insert < 677678989', NULL, '40.0'> into WORKS_ON . cant have null for PNo so I chose 1
INSERT INTO WorksOn (ESSN, PNo, Hours)
VALUES ('677678989', 1, 40.0);

-- e. Insert <'453453453', 'John', "M', 1990-12-12', 'spouse'> into DEPENDENT.
INSERT INTO Dependent (ESSN, DependentName, Sex, BDate, Relationship)
VALUES ('453453453', 'John', 'M', '1990-12-12', 'Spouse');

-- f. Delete the WORKS_ON tuples with Essn = '333445555'.
DELETE FROM WorksOn WHERE ESSN = '333445555';

﻿﻿﻿-- g. Delete the EMPLOYEE tuple with Ssn = '987654321'.  THIS WAS THE ONLY ONE I WAS HAVING TROUBLE WITH I COULD NOT FIGURE IT OUT
DELETE FROM Employee WHERE SSN = '987654321';

﻿﻿﻿-- h. Delete the PROJECT tuple with Pname = 'ProductX'.
SELECT PNumber FROM Project WHERE PName = 'ProductX';

﻿﻿﻿-- i. Modify the Mgr_ssn and Mgr_start_date of the DEPARTMENT tuple with Dnumber = 5 to '123456789' and '2007-10-01', respectively.
UPDATE Department
SET MgrSSN = '123456789', MgrStartDate = '2007-10-01'
WHERE DNumber = 5;

﻿﻿﻿-- j. Modify the Super_ssn attribute of the EMPLOYEE tuple with Ssn = '999887777' to '943775543'.
UPDATE Employee
SET SuperSSN = '943775543'
WHERE SSN = '999887777';

-- k. Modify the Hours attribute of the WORKS_ON tuple with Essn = '999887777' and Pno = 10 to '5.0'.
UPDATE WorksOn
SET Hours = 5.0
WHERE ESSN = '999887777' AND PNo = 10;










