USE CompanyDB2;

-- a. Retrieve the names of all employees in department 5 who work more than 10 hours per week on the ProductX project.
SELECT DISTINCT E.FName, E.LName
FROM Employee E
JOIN WorksOn W ON E.SSN = W.ESSN
JOIN Project P ON W.PNo = P.PNumber
WHERE E.DNo = 5 AND P.PName = 'ProductX' AND W.Hours > 10;

-- b. List the names of all employees who have a dependent with the same first name as themselves.
SELECT DISTINCT E.FName, E.LName
FROM Employee E
JOIN Dependent D ON E.SSN = D.ESSN
WHERE E.FName = D.DependentName;

-- c. Find the names of all employees who are directly supervised by 'Franklin Wong'.
SELECT E.FName, E.LName
FROM Employee E
JOIN Employee S ON E.SuperSSN = S.SSN
WHERE S.FName = 'Franklin' AND S.LName = 'Wong';

-- d. For each project, list the project name and the total hours per week (by all employees) spent on that project.
SELECT P.PName, SUM(W.Hours) AS Total_Hours
FROM Project P
JOIN WorksOn W ON P.PNumber = W.PNo
GROUP BY P.PName;

-- e. Retrieve the names of all employees who work on every project.
SELECT E.FName, E.LName
FROM Employee E
WHERE NOT EXISTS (
    SELECT P.PNumber
    FROM Project P
    WHERE NOT EXISTS (
        SELECT W.ESSN
        FROM WorksOn W
        WHERE W.PNo = P.PNumber AND W.ESSN = E.SSN
    )
);

-- f. Retrieve the names of all employees who do not work on any project.
SELECT E.FName, E.LName
FROM Employee E
LEFT JOIN WorksOn W ON E.SSN = W.ESSN
WHERE W.ESSN IS NULL;

-- g. For each department, retrieve the department name and the average salary of all employees working in that department.
SELECT D.DName, AVG(E.Salary) AS Avg_Salary
FROM Department D
JOIN Employee E ON D.DNumber = E.DNo
GROUP BY D.DName;

-- h. Retrieve the average salary of all female employees.
SELECT AVG(Salary) AS Avg_Female_Salary
FROM Employee
WHERE Sex = 'F';


-- i. Find the names and addresses of all employees who work on at least one project located in Houston but whose department has no location in Houston.
SELECT DISTINCT E.FName, E.LName, E.Address
FROM Employee E
JOIN WorksOn W ON E.SSN = W.ESSN
JOIN Project P ON W.PNo = P.PNumber
WHERE P.PLocation = 'Houston'
AND E.DNo NOT IN (
    SELECT DNumber FROM DeptLocations WHERE DLocation = 'Houston'
);

-- j. List the last names of all department managers who have no dependents.
SELECT DISTINCT E.LName
FROM Employee E
JOIN Department D ON E.SSN = D.MgrSSN
LEFT JOIN Dependent Dep ON E.SSN = Dep.ESSN
WHERE Dep.ESSN IS NULL;