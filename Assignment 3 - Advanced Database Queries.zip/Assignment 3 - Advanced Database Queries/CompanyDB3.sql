-- Problem 7.5: Aggregate Queries
-- (a) Retrieve departments where the average salary is more than $30,000, including department name and employee count.
SELECT D.DName, COUNT(E.SSN) AS NumEmployees
FROM Employee E
JOIN Department D ON E.DNo = D.DNumber
GROUP BY D.DName
HAVING AVG(E.Salary) > 30000;

-- (b) Can we get the number of male employees in each department making more than $30,000?
SELECT D.DName, COUNT(E.SSN) AS NumMaleEmployees
FROM Employee E
JOIN Department D ON E.DNo = D.DNumber
WHERE E.Sex = 'M' AND E.Salary > 30000
GROUP BY D.DName;

-- Problem 7.7: Nested Queries
-- (a) Find employees in the same department as the highest-paid employee.
SELECT FName, LName
FROM Employee
WHERE DNo = (
    SELECT DNo FROM Employee
    ORDER BY Salary DESC LIMIT 1
);

-- (b) Retrieve employees whose supervisor's supervisor has SSN = '8886665555'.
SELECT E.FName, E.LName
FROM Employee E
JOIN Employee S1 ON E.SuperSSN = S1.SSN
JOIN Employee S2 ON S1.SuperSSN = S2.SSN
WHERE S2.SSN = '8886665555';

-- (c) Find employees who earn at least $10,000 more than the lowest-paid employee.
SELECT FName, LName
FROM Employee
WHERE Salary >= (
    SELECT MIN(Salary) FROM Employee
) + 10000;
